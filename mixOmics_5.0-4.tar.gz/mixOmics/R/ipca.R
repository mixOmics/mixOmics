# Copyright (C) 2009 
# Kim-Anh L� Cao, French National Institute for Agricultural Research and 
# Queensland Facility for Bioinformatics, University of Queensland, Australia
# Fangzhou Yao, Queensland Facility for Advanced Bioinformatics, University of Queensland, Australia and
# Shangai University of Finance and Economics, Shanghai, P.R. China
# Jeff Coquery, Queensland Facility for Advanced Bioinformatics, University of Queensland, Australia and
# Sup Biotech, Paris, France
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
# The function ica.par and ica.def are borrowed from the fastICA package (see references).


ipca <-
function (X, ncomp = 3, mode = c("deflation","parallel"),
          fun = c("logcosh", "exp"),
          scale = FALSE, max.iter = 200,
          tol = 1e-04, w.init= NULL)
{
    dim_x <- dim(X)
    d <- dim_x[dim_x != 1]
    if (length(d) != 2)
        stop("data must be in a matrix form")
    X <- if (length(d) != length(dim_x))
        {matrix(X, d[1], d[2])}
    else {as.matrix(X)}

    alpha <- 1
    
    mode <- match.arg(mode)
    fun <- match.arg(fun)
    
    X.names = dimnames(X)[[2]]
    if (is.null(X.names)) X.names = paste("X", 1:ncol(X), sep = "")

    ind.names = dimnames(X)[[1]]
    if (is.null(ind.names)) ind.names = 1:nrow(X)
	
    X <- scale(X, scale = FALSE)
    if (scale) {X=scale(X, scale=scale)}
    svd_mat <- svd(X)
    right_sing_vect <- svd_mat$v
    right_sing_vect <- scale(right_sing_vect, center=TRUE, scale=TRUE)
    n <- nrow(t(X))
    p <- ncol(t(X))
    
    if (ncomp > min(n, p)) {
        message("'ncomp' is too large: reset to ", min(n, p))
        ncomp <- min(n, p)
    }
    if(is.null(w.init))
        w.init <- matrix(1/sqrt(ncomp),ncomp,ncomp)
    else {
        if(!is.matrix(w.init) || length(w.init) != (ncomp^2))
            stop("w.init is not a matrix or is the wrong size")
    }
    
    X1 <- t(right_sing_vect)[1:ncomp,]
         
        if (mode == "deflation") {
            unmix_mat <- ica.def(X1, ncomp, tol = tol, fun = fun,
                           alpha = alpha, max.iter = max.iter, verbose = FALSE, w.init = w.init)
        }
        else if (mode == "parallel") {
            unmix_mat <- ica.par(X1, ncomp, tol = tol, fun = fun,
                           alpha = alpha, max.iter = max.iter, verbose = TRUE, w.init = w.init)
        }
        w <- unmix_mat 
        independent_mat <- w %*% X1
        #==order independent_mat by kurtosis==#
           kurt <- vector(length=ncomp)
           independent_mat.new <- matrix(nrow = ncomp, ncol = n)
           for(h in 1:ncomp){
               kurt[h] <- (mean(independent_mat[h,]^4)-3*(mean(independent_mat[h,]^2))^2)
               }
           for(i in 1:ncomp){
               independent_mat.new[i,] <- independent_mat[order(kurt,decreasing=TRUE)[i],]
               independent_mat.new[i,] <- independent_mat.new[i,]/crossprod(independent_mat.new[i,]) 
               }         
        
        mix_mat <- t(w) %*% solve(w %*% t(w))

        ipc_mat = matrix(nrow=p, ncol=ncomp)
        ipc_mat = X %*% t(independent_mat.new)        
        ##== force orthogonality ==##
          for(h in 1:ncomp){
              if(h==1){ipc_mat[,h]=X %*% (t(independent_mat.new)[,h])}
              if(h>1){ipc_mat[,h]=(lsfit(y=X%*%(t(independent_mat.new)[,h]), ipc_mat[,1:(h-1)],intercept=FALSE)$res)}
              ipc_mat[,h]=ipc_mat[,h]/sqrt(crossprod(ipc_mat[,h]))
              }
        ##== force over ==##   

# put rownames of loading vectors
	colnames(independent_mat.new) = colnames(X)

             
        cl = match.call()
		cl[[1]] = as.name('ipca')
		
        result = list(call=cl, X = X, ncomp=ncomp, unmixing = t(unmix_mat), mixing = t(mix_mat), loadings = t(independent_mat.new), kurtosis = kurt[order(kurt,decreasing=TRUE)],
		names = list(X = X.names, indiv = ind.names))
		
		result$x = ipc_mat
        dimnames(result$x) = list(ind.names, paste("IPC", 1:ncol(result$loadings), sep = " "))
			
		class(result) = c("ipca")
		return(invisible(result))
	} 
